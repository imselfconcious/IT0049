<?php

namespace App\Controllers;

use App\Models\CustomerModel;

class Customers extends BaseController
{
    protected $customerModel;

    public function __construct()
    {
        $this->customerModel = new CustomerModel();
    }

    // Read: Displays non-archived customer records
    public function index()
    {
        $data['customers'] = $this->customerModel->getActiveCustomers();
        return view('customers/index', $data);
    }

    // Create View
    public function new()
    {
        return view('customers/create');
    }

    // Insert Action
    public function create()
    {
        if (!$this->customerModel->save([
            'full_name' => $this->request->getPost('full_name'),
            'email'     => $this->request->getPost('email'),
            'phone'     => $this->request->getPost('phone'),
        ])) {
            return redirect()->back()->withInput()->with('errors', $this->customerModel->errors());
        }

        return redirect()->to('/customers')->with('success', 'Customer created successfully.');
    }

    // Edit View
    public function edit($id = null)
    {
        $data['customer'] = $this->customerModel->find($id);
        if (!$data['customer'] || $data['customer']['is_archived']) {
            return redirect()->to('/customers')->with('error', 'Customer not found.');
        }
        return view('customers/edit', $data);
    }

    // Update Action
    public function update($id = null)
    {
        if (!$this->customerModel->update($id, [
            'full_name' => $this->request->getPost('full_name'),
            'email'     => $this->request->getPost('email'),
            'phone'     => $this->request->getPost('phone'),
        ])) {
            return redirect()->back()->withInput()->with('errors', $this->customerModel->errors());
        }

        return redirect()->to('/customers')->with('success', 'Customer updated successfully.');
    }

    // Soft Delete Action (is_archived = 1)
    public function delete($id = null)
    {
        $this->customerModel->update($id, ['is_archived' => 1]);
        return redirect()->to('/customers')->with('success', 'Customer archived successfully.');
    }
}