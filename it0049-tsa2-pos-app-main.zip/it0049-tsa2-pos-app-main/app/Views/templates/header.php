<nav>
    <a href="<?= site_url('/') ?>">Home</a> |
    <a href="<?= site_url('/about') ?>">About</a> |
    <a href="<?= site_url('/customers') ?>">Customer Accounts</a> |
    <a href="<?= site_url('/users') ?>">User Accounts</a> |
    <?php if (session()->get('isLoggedIn')): ?>
        <span>Logged in as: <?= session()->get('username') ?></span> |
        <a href="<?= site_url('/logout') ?>">Logout</a>
    <?php else: ?>
        <a href="<?= site_url('/login') ?>">Login</a>
    <?php endif; ?>
</nav>
<hr>