<?= $this->include('templates/header') ?>

<h2>Customer Accounts</h2>

<?php if (session()->getFlashdata('success')): ?>
    <p style="color: green;"><?= session()->getFlashdata('success') ?></p>
<?php endif; ?>

<?php if (session()->get('isLoggedIn')): ?>
    <p><a href="<?= site_url('/customers/new') ?>">+ Add New Customer</a></p>
<?php endif; ?>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Phone</th>
            <?php if (session()->get('isLoggedIn')): ?>
                <th>Actions</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($customers as $customer): ?>
        <tr>
            <td><?= $customer['id'] ?></td>
            <td><?= esc($customer['full_name']) ?></td>
            <td><?= esc($customer['email']) ?></td>
            <td><?= esc($customer['phone']) ?></td>
            <?php if (session()->get('isLoggedIn')): ?>
                <td>
                    <a href="<?= site_url('/customers/edit/' . $customer['id']) ?>">Edit</a> |
                    <a href="<?= site_url('/customers/delete/' . $customer['id']) ?>" onclick="return confirm('Archive this record?')">Delete</a>
                </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>