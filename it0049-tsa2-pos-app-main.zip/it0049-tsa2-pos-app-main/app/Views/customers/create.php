<?= $this->include('templates/header') ?>

<h2>Add New Customer</h2>

<?php if (session()->getFlashdata('errors')): ?>
    <ul style="color: red;">
        <?php foreach (session()->getFlashdata('errors') as $error): ?>
            <li><?= esc($error) ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<form action="<?= site_url('/customers/create') ?>" method="post">
    <?= csrf_field() ?>
    <p>
        <label>Full Name:</label><br>
        <input type="text" name="full_name" value="<?= old('full_name') ?>">
    </p>
    <p>
        <label>Email:</label><br>
        <input type="email" name="email" value="<?= old('email') ?>">
    </p>
    <p>
        <label>Phone:</label><br>
        <input type="text" name="phone" value="<?= old('phone') ?>">
    </p>
    <button type="submit">Save Customer</button>
</form>