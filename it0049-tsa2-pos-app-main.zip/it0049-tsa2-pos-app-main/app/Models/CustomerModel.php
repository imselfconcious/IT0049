<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table            = 'customers';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['full_name', 'email', 'phone', 'is_archived'];
    
    // Validation rules
    protected $validationRules = [
        'full_name' => 'required|min_length[3]',
        'email'     => 'required|valid_email',
        'phone'     => 'required|numeric|min_length[10]'
    ];
    
    public function getActiveCustomers()
    {
        return $this->where('is_archived', 0)->findAll();
    }
}